#!/usr/bin/env python3
"""
load_model.py - Minimal loader for the XLSR-Mamba Indic fine-tune.

Usage:
  # self-contained (this release's full checkpoint):
  python load_model.py --model_indic_ft.safetensors

  # reconstruct from the lightweight head-only file + a base checkpoint you already have:
  python load_model.py --base model.safetensors --head conformer_head_only.safetensors
"""

import argparse, os, sys
import torch
from safetensors import safe_open
from safetensors.torch import load_file

# evaluate_model.py (Model, SSLModel, MixerModel, ...) lives in the companion repo:
# https://github.com/ this project's root, alongside model.safetensors / ASVspoof5.*.tsv
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
try:
    from evaluate_model import Model
except ImportError:
    sys.exit("Put this script next to (or point sys.path at) the companion repo's "
             "evaluate_model.py, which defines the Model/SSLModel/MixerModel classes.")


def load(full_ckpt=None, base_ckpt=None, head_ckpt=None, device="cpu"):
    model = Model(emb_size=144, num_encoders=12)
    if full_ckpt:
        sd = load_file(full_ckpt, device="cpu")
    else:
        sd = load_file(base_ckpt, device="cpu")
        with safe_open(head_ckpt, framework="pt", device="cpu") as f:
            for k in f.keys():
                sd[k] = f.get_tensor(k)
    missing, unexpected = model.load_state_dict(sd, strict=False)
    if missing or unexpected:
        raise SystemExit(f"tensor mismatch: {len(missing)} missing, {len(unexpected)} unexpected "
                         "-- wrong architecture or corrupt checkpoint")
    return model.eval().to(device)


if __name__ == "__main__":
    pa = argparse.ArgumentParser()
    pa.add_argument("--full", help="model_indic_ft.safetensors (self-contained)")
    pa.add_argument("--base", help="base model.safetensors (backbone + front-end)")
    pa.add_argument("--head", help="conformer_head_only.safetensors (fine-tuned head)")
    pa.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = pa.parse_args()
    if not args.full and not (args.base and args.head):
        pa.error("pass either --full, or both --base and --head")
    m = load(args.full, args.base, args.head, args.device)
    n = sum(p.numel() for p in m.parameters()) / 1e6
    print(f"loaded OK on {args.device}: {n:.1f}M params")
